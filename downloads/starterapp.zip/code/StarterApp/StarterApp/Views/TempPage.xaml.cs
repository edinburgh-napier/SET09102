namespace StarterApp.Views;

public partial class TempPage : ContentPage
{
	public TempPage()
	{
		InitializeComponent();
	}
}